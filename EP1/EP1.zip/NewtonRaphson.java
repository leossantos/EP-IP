/*********************************************************************/
/**   <nome do(a) aluno(a)>                   <número USP>          **/
/**                                                                 **/
/**   <data de entrega>                                             **/
/*********************************************************************/
class NewtonRaphson {
	/*
		Depósitos realizados, com saldo final
	*/
	static double[] depositos = new double[11];
	
	/*
		Datas correspondentes aos depósitos feitos e saldo final
	*/
	static int[] datas = new int[11];
	
	/*
		Você pode incluir métodos que ache necessários aqui. Contudo, apenas newton
		será executado diretamente. Então, para que seus métodos rodem, deve haver um
		caminho em que sejam rodados a partir de newton (ex: newton chama um método que
		chama outro. Nesse caso, os 2 acabarão sendo rodados via newton)
	*/
	

	/*
		Método para cálculo dos juros de aplicação, segundo Newton-Raphson
	*/
	static double newton(double epsilon) {
		// seu código vai aqui
	}
	
	/*
		Use isso apenas para seus testes. Ele pode até ser removido para entrega. Use-o para abastecer valores nos arranjos e então testar o método newton.
		
		O MAIN SERÁ COMPLETAMENTE IGNORADO.
	*/
	public static void main(String args) {
		// será ignorado
	}
}
